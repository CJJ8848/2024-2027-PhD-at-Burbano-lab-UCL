library(ape)
library(pegas)
setwd('/Users/cuijiajun/Desktop/others/tmphernan/2024nov_runtapemeasure/talia-backman/comparetapemeasurelengthinmydata/pega_haplotypeidentification/')

msa<-read.dna('./dnadifflength_bigdataset/length_2526allOTU5.fasta',format = "fasta")

# Step 2: Compute haplotypes, considering genetic and length differences
# The haplotype function will automatically consider sequence length as part of the differences
h <- haplotype(msa)
d <- dist.dna(h, "N")
nt <- rmst(d, quiet = TRUE)
nt
p<-plot(nt)
# Open PNG device
png('2526_OTU5_haplotypenet.png', width = 800, height = 600)  # You can adjust width and height as needed

# Plot the haplotype network
plot(nt)

# Close the PNG device
dev.off()

(sz <- summary(h))
#reorder
(nt.labs <- attr(nt, "labels"))
sz <- sz[nt.labs]
png('size2526_OTU5_haplotypenet.png', width = 800, height = 600)  # You can adjust width and height as needed

# Plot the haplotype network
plot(nt, size = sz)
# Close the PNG device
dev.off()

replot()





library(ape)
library(pegas)
setwd('/Users/cuijiajun/Desktop/others/tmphernan/2024nov_runtapemeasure/talia-backman/comparetapemeasurelengthinmydata/pega_haplotypeidentification/')

msa<-read.dna('./length_2280.fasta',format = "fasta")

# Step 2: Compute haplotypes, considering genetic and length differences
# The haplotype function will automatically consider sequence length as part of the differences
h <- haplotype(msa)
d <- dist.dna(h, "N")
nt <- rmst(d, quiet = TRUE)
nt
p<-plot(nt)
# Open PNG device
png('2280_22OTU5_haplotypenet.png', width = 800, height = 600)  # You can adjust width and height as needed

# Plot the haplotype network
plot(nt)

# Close the PNG device
dev.off()

(sz <- summary(h))
#reorder
(nt.labs <- attr(nt, "labels"))
sz <- sz[nt.labs]
png('size2280_22OTU5_haplotypenet.png', width = 800, height = 600)  # You can adjust width and height as needed

# Plot the haplotype network
plot(nt, size = sz)
# Close the PNG device
dev.off()

#replot()

#nonOTU5 
library(ape)
library(pegas)
setwd('/Users/cuijiajun/Desktop/others/tmphernan/2024nov_runtapemeasure/talia-backman/comparetapemeasurelengthinmydata/pega_haplotypeidentification/')

msa<-read.dna('./length_2157.fasta',format = "fasta")

# Step 2: Compute haplotypes, considering genetic and length differences
# The haplotype function will automatically consider sequence length as part of the differences
h <- haplotype(msa)
d <- dist.dna(h, "N")
nt <- rmst(d, quiet = TRUE)
nt
p<-plot(nt)
# Open PNG device
png('2157_9_OTU5_haplotypenet.png', width = 800, height = 600)  # You can adjust width and height as needed

# Plot the haplotype network
plot(nt)

# Close the PNG device
dev.off()

(sz <- summary(h))
#reorder
(nt.labs <- attr(nt, "labels"))
sz <- sz[nt.labs]
png('size2157_9_OTU5_haplotypenet.png', width = 800, height = 600)  # You can adjust width and height as needed

# Plot the haplotype network
plot(nt, size = sz)
# Close the PNG device
dev.off()

replot()

