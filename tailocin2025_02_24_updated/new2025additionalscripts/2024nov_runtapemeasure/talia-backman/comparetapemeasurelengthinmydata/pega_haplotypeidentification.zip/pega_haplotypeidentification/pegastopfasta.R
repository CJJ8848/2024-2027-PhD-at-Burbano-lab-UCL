library(ape)
library(pegas)

# Set working directory and read DNA data
setwd('/Users/cuijiajun/Desktop/others/tmphernan/2024nov_runtapemeasure/talia-backman/comparetapemeasurelengthinmydata/pega_haplotypeidentification/')
msa <- read.dna('./dnadifflength_bigdataset/length_2526allOTU5.fasta', format = "fasta")
#msa <- read.dna('./dnadifflength_bigdataset/length_2280.fasta', format = "fasta")

# Compute haplotypes and summarize
h <- haplotype(msa)
sz <- summary(h)

# Extract top 5 haplotypes based on their frequencies
top_haplotypes <- names(sort(sz, decreasing = TRUE)[1:3])

# Map Roman numeral haplotype names to their corresponding numeric indices
index_list <- attr(h, "index")

# Create a vector to convert numeric indices to Roman numerals
numeric_to_roman <- function(n) {
  roman_numerals <- c("I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII", "XIII", "XIV", "XV")
  return(roman_numerals[n])
}

# Create a data frame to store sample names and their haplotypes
sample_haplotype_df <- data.frame(Sample = character(0), Haplotype = character(0), stringsAsFactors = FALSE)

# Extract and save each top haplotype sequence as a separate FASTA file
for (hap_name in top_haplotypes) {
  # Find the numeric index that corresponds to the Roman numeral haplotype name
  num_index <- which(sapply(1:length(index_list), numeric_to_roman) == hap_name)
  
  if (length(num_index) > 0) {
    # Get the indices of the sequences corresponding to the current haplotype
    which_hap <- index_list[[num_index]]
    hap_seq <- msa[which_hap, , drop = FALSE]  # Extract the sequence(s)
    
    # Write to a FASTA file named after the haplotype
    write.dna(hap_seq, file = paste0("haplotype_", hap_name, ".fasta"), format = "fasta")
    
    # Add sample names and their haplotype to the data frame
    sample_names <- rownames(msa)[which_hap]
    sample_haplotype_df <- rbind(sample_haplotype_df, data.frame(Sample = sample_names, Haplotype = hap_name))
  }
}
# Remove the "Seq*" prefix from the Sample column
sample_haplotype_df$Sample <- sub("^Seq[0-9]+_", "", sample_haplotype_df$Sample)
sample_haplotype_df$Haplotype <- paste0("2526_", sample_haplotype_df$Haplotype)

# Save the sample-haplotype mapping as a text file
write.table(sample_haplotype_df, file = "sample_haplotype_mapping.txt", row.names = FALSE, quote = FALSE, sep = "\t")

cat("Top haplotype sequences have been saved as separate FASTA files and sample-haplotype mapping saved as a text file.\n")