for file in *.fasta; do
  echo -n "$file: "  # Print the file name without a newline
  awk '/^>/ {if (seqlen){print seqlen}; seqlen=0; next} {gsub("[- ]", ""); seqlen += length($0)} END {if (seqlen) print seqlen}' "$file" | sort | uniq -c
done