#!/bin/bash


# Define input and output files
input_fasta="tape_measureGC00000514_13.pal2nal"
sample_list="1355OTU5.txt"
output_matched="matched_samples.pal2nal"
output_unmatched="unmatched_samples.pal2nal"

# Extract sequences with headers matching the names in $sample_list
awk 'NR==FNR {names[$1]; next} /^>/ {
    print_seq = 0;
    header=$0;
    if (match(header, /_p[0-9]+\.[A-Z][0-9]+/)) {
        extracted_name = substr(header, RSTART + 1, RLENGTH - 1);
        if (extracted_name in names) {
            print_seq = 1;
            print header > "'"$output_matched"'"
        } else {
            print header > "'"$output_unmatched"'"
        }
    } else {
        print header > "'"$output_unmatched"'"
    }
    next
}
print_seq { print > "'"$output_matched"'" }
!print_seq { print > "'"$output_unmatched"'" }' "$sample_list" "$input_fasta"
