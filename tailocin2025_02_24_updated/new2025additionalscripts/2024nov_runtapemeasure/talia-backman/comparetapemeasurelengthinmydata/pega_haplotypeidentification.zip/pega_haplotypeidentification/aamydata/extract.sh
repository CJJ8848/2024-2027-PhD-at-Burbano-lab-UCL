#!/bin/bash

# Input file paths
fasta_file="aa49_noHB0814_nop25.C11emboss_transeq-I20241115-015315-0305-24837432-p1m.out"
extracted_file="short2280_extracted_sequences.fasta"
shorter_file="longer.fasta"
#all 2526 except p4.D2 2403
# List of sample names to extract
sample_list=("p12.E2_tape" "p13.C1_tape" "p13.C7_tape" "p13.D10_tape" "p13.F3_tape"
             "p20.D4_tape" "p21.E3_tape" "p21.F1_tape" "p22.A8_tape" "p22.B5_tape"
             "p24.H2_tape" "p26.B7_tape" "p27.D6_tape" "p4.E5_tape" "p4.E6_tape"
             "p5.C3_tape" "p5.H11_tape" "p6.A10_tape" "p7.G11_tape" "p8.B9_tape"
             "p8.E4_tape" "p8.H7_tape")

# Create a regular expression from the sample list
regex=$(printf "|%s" "${sample_list[@]}")
regex="${regex:1}" # Remove leading pipe

# Extract matched sequences to extracted_file
awk -v regex="$regex" '
    BEGIN { print_seq = 0 }
    /^>/ { print_seq = ($0 ~ regex) ? 1 : 0 }
    { if (print_seq) print }
' "$fasta_file" > "$extracted_file"

# Extract non-matched sequences to shorter_file
awk -v regex="$regex" '
    BEGIN { print_seq = 1 }
    /^>/ { print_seq = ($0 ~ regex) ? 0 : 1 }
    { if (print_seq) print }
' "$fasta_file" > "$shorter_file"

echo "Sequences extracted to $extracted_file"
echo "Remaining sequences saved to $shorter_file"
