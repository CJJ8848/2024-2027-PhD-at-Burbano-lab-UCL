#!/bin/bash

# Define input and output files
output_cleaned_fasta="1380OTU5tapemeasure.fasta"
output_names="1380OTU5tapemeasure_lengths_sorted.txt"
output_extracted_fasta="55OTU5_extracted.fasta"
output_lengths="55OTU5sequence_lengths.txt"

# Extract the sequences with headers matching the names in $output_names
awk 'NR==FNR {names[$1]; next} /^>/ {
    print_seq = 0;
    header=$0;
    if (match(header, /_p[0-9]+\.[A-Z][0-9]+/)) {
        extracted_name = substr(header, RSTART + 1, RLENGTH - 1);
        if (extracted_name in names) {
            print_seq = 1;
            print header;
        }
    }
    next
}
print_seq' "$output_names" "$output_cleaned_fasta" > "$output_extracted_fasta"



awk '/^>/ {if (seqlen){print seqlen}; seqlen=0; next} {seqlen += length($0)} END {if (seqlen) print seqlen}' $output_extracted_fasta | sort | uniq -c > $output_lengths

# Notify user of completion
echo " and sequence lengths with counts written to $output_lengths." 
# Notify user of completion
echo "Extracted sequences written to $output_extracted_fasta."