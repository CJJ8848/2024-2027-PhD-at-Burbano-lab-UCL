#!/bin/bash

# Define input and output files
#input_fasta="1380OTU5tapemeasure.fasta"
#lengths_file="1380OTU5tapemeasure_lengths_sorted.txt"
#output_dir="extracted_by_length"
input_fasta=$1
lengths_file=$2
output_dir=$3
# Ensure the output directory exists
mkdir -p "$output_dir"

# Read each unique length from the lengths file
awk '{print $2}' "$lengths_file" | sort -n | uniq | while read -r length; do
    # Define the output file for the current length
    output_fasta="${output_dir}/length_${length}.fasta"

    # Extract sequences of the current length
    awk -v target_length="$length" -v output_fasta="$output_fasta" '
    BEGIN {print_seq = 0}
    NR == FNR {
        # Build a dictionary of sequence names with the target length
        if ($2 == target_length) {
            lengths[$1];
        }
        next;
    }
    /^>/ {
        # Check if the header matches a sequence name
        header = substr($0, 2);
        print_seq = (header in lengths) ? 1 : 0;
        if (print_seq) {
            print $0 > output_fasta;
        }
        next;
    }
    {
        # Print sequence lines only if the header matched
        if (print_seq) {
            print $0 > output_fasta;
        }
    }
    ' "$lengths_file" "$input_fasta"

    # Check if the output FASTA file has content
    if [[ -s "$output_fasta" ]]; then
        echo "Generated $output_fasta for length $length."
    else
        echo "No sequences found for length $length. Removing empty file."
        rm -f "$output_fasta"
    fi
done

echo "All sequences have been grouped by length into the folder: $output_dir"
